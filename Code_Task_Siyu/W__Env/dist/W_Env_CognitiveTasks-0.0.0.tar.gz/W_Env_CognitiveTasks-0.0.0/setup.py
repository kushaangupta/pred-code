import setuptools

setuptools.setup(
    name='W_Env_CognitiveTasks',
    version = '0.0.0',
    description='siyu''s environments',
    author='Siyu Wang',
    author_email='wangxsiyu@gmail.com',
    packages = setuptools.find_packages(),
    install_requires =[],
    zip_safe=False
)