import setuptools

setuptools.setup(
    name='W_Python',
    version = '0.0.0',
    description='siyu''s python functions',
    author='Siyu Wang',
    author_email='wangxsiyu@gmail.com',
    packages = setuptools.find_packages(),
    install_requires =['numpy'],
    zip_safe=False
)